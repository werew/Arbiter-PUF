#!/bin/sh

gcc -o randomcatserver -O3 -Wall randomcatserver.c
