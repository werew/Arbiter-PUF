import network
import socket
import machine

SERVER_NAME = "192.168.150.199"
SERVER_PORT = 10000
WIFI_SSID = "esp8266"
WIFI_PSK = "twente2018"

pin = machine.Pin(2, machine.Pin.OUT)

sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)
sta_if.connect(WIFI_SSID, WIFI_PSK)
while not sta_if.isconnected():
    pass

addr_info = socket.getaddrinfo(SERVER_NAME, SERVER_PORT)
addr = addr_info[0][-1]
s = socket.socket()
s.connect(addr)
while True:
    data = s.recv(1)
    if (data == b'0'):
        print("Off")
        pin.on()
    elif (data == b'1'):
        print("On")
        pin.off()
